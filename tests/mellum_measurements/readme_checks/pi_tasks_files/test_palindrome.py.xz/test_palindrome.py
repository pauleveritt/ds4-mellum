import unittest
from palindrome import is_palindrome

class TestPalindrome(unittest.TestCase):
    def test_simple(self):
        self.assertTrue(is_palindrome("racecar"))
        self.assertFalse(is_palindrome("hello"))
    
    def test_case_insensitive(self):
        self.assertTrue(is_palindrome("RaceCar"))
        self.assertTrue(is_palindrome("RaCeCaR"))
    
    def test_non_alphanumeric(self):
        self.assertTrue(is_palindrome("A man, a plan, a canal: Panama"))
        self.assertTrue(is_palindrome("No 'x' in Nixon"))
        self.assertFalse(is_palindrome("Hello, world!"))
    
    def test_empty_string(self):
        self.assertTrue(is_palindrome(""))
    
    def test_single_character(self):
        self.assertTrue(is_palindrome("a"))
        self.assertTrue(is_palindrome("1"))

if __name__ == '__main__':
    unittest.main()
